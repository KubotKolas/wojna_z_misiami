#pragma once

void mainLoop(int docks, int mechs, int proc_number);

int rollDmg(int upper_limit);

int repair();